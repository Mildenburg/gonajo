// Impprtacion de las clases 
import { Escritor, Aventuras, CienciaFiccion, Fantasia, Policiaca, Terror, Romantica, Poesia, Mitologia, Teatro, Cuento } from './class.js';
// Arrays para guardar libros y escritores
const libros = [];
const escritores = [];

// Consle.log para ver la array
console.log("Libros:", libros);
console.log("Escritores:", escritores);

document.addEventListener('DOMContentLoaded', async () => {
    try {
        const resLibros = await fetch('/api/libros');
        const dataLibros = await resLibros.json();
        libros.push(...dataLibros);

        const resEscritores = await fetch('/api/escritores');
        const dataEscritores = await resEscritores.json();
        dataEscritores.forEach(escritorData => {
            const escritor = new Escritor(escritorData.nombre);
            escritores.push(escritor);
        });

        // Botones para buscar libros por autor 
        document.getElementById('searchButtonEscritores').addEventListener('click', buscarEscritor);
        document.getElementById('searchButtonNomLibro').addEventListener('click', buscarLibroPorNombre);
        document.getElementById('searchButtonGenero').addEventListener('click', buscarLibroPorGenero);
    } catch (error) {
        console.error('Error cargando datos:', error);
    }
});
// Función para buscar libros por Nombre
async function buscarLibroPorNombre() {
    const nombreLibro = document.getElementById('buscarNomLibro').value.trim(); // Eliminar espacios en blanco al principio y al final
    const resultadosNombre = document.getElementById('searchResultsNombre');

    // Verificar si el campo de búsqueda está vacío
    if (nombreLibro === '') {
        // Si está vacío, no realizar ninguna acción y salir de la función
        return;
    }

    try {
        const response = await fetch(`/api/libros?titulo=${encodeURIComponent(nombreLibro)}`);
        if (!response.ok) {
            const errorMessage = await response.text();
            throw new Error(errorMessage);
        }
        const librosEncontrados = await response.json();
        // Verificar si se encontraron libros nuevos
        if (librosEncontrados.length > 0) {
            // Borrar resultados anteriores solo si se encontraron libros
            resultadosNombre.innerHTML = '';
            const libro = librosEncontrados[0];
            const escritor = libro.escritor;
            const genero = libro.genero;
            resultadosNombre.innerHTML = `<h3>El libro "${nombreLibro}" del género "${genero}"</h3>`;
            resultadosNombre.innerHTML += `<p>Del autor ${escritor}</p>`;
            
            // Buscar más libros del mismo autor
            const responseMasLibros = await fetch(`/api/libros?escritor=${encodeURIComponent(escritor)}`);
            if (!responseMasLibros.ok) {
                const errorMessage = await responseMasLibros.text();
                throw new Error(errorMessage);
            }
            const masLibros = await responseMasLibros.json();
            if (masLibros.length > 1) {
                resultadosNombre.innerHTML += `<h3>El autor ${escritor} también ha escrito estos libros:</h3>`;
                mostrarResultados(resultadosNombre, masLibros.filter(lib => lib.titulo !== nombreLibro), '');
            } else {
                resultadosNombre.innerHTML += `<p>No se han encontrado más libros para este autor.</p>`;
            }
        } else {
            resultadosNombre.innerHTML = '<p>No se ha encontrado ningún libro con este nombre.</p>';
        }
    } catch (error) {
        console.error('Error:', error);
        resultadosNombre.innerHTML = '<p>Error al buscar el libro.</p>';
    }
    // Vaciar el campo de búsqueda
    document.getElementById('buscarNomLibro').value = '';
}

// Función para buscar un escritor y mostrar sus libros
async function buscarEscritor() {
    const nombreEscritor = document.getElementById('buscarEscritor').value;
    const resultados = document.getElementById('searchResults');

    if (!nombreEscritor) {
        return;
    }


    try {
        const response = await fetch(`/api/libros?escritor=${encodeURIComponent(nombreEscritor)}`);
        if (!response.ok) {
            const errorMessage = await response.text();
            throw new Error(errorMessage);
        }
        const librosEscritos = await response.json();
        if (librosEscritos.length > 0) {
            mostrarResultados(resultados, librosEscritos, `Libros escritos por ${nombreEscritor}:`);
        } else {
            resultados.innerHTML = '<p>No se ha encontrado ningún libro para este escritor.</p>';
        }
    } catch (error) {
        console.error('Error:', error);
        resultados.innerHTML = '<p>Error al buscar los libros del escritor.</p>';
    }
    document.getElementById('buscarEscritor').value = '';
}

// Función para buscar libros por Género
async function buscarLibroPorGenero() {
    const generoSeleccionado = document.getElementById('buscarLibroGenero').value;
    const resultadosGenero = document.getElementById('searchResultsGenero');

    if (!generoSeleccionado) {
        return;
    }

    try {
        const response = await fetch(`/api/libros?genero=${encodeURIComponent(generoSeleccionado)}`);
        if (!response.ok) {
            const errorMessage = await response.text();
            throw new Error(errorMessage);
        }
        const librosEncontrados = await response.json();
        if (librosEncontrados.length > 0) {
            resultadosGenero.innerHTML = '';
            mostrarResultados(resultadosGenero, librosEncontrados, `Resultados para el género ${generoSeleccionado}:`);
        } else {
            resultadosGenero.innerHTML = '<p>No se ha encontrado ningún libro para este género.</p>';
        }
    } catch (error) {
        console.error('Error:', error);
        resultadosGenero.innerHTML = '<p>Error al buscar los libros del género.</p>';
    }
    document.getElementById('buscarLibroGenero').value = '';
}

// Función para mostrar los resultados
function mostrarResultados(container, libros, mensaje) {
    if (mensaje) {
        container.innerHTML += `<h3>${mensaje}</h3>`;
    }
    const ul = document.createElement('ul');
    libros.forEach(libro => {
        const li = document.createElement('li');
        li.textContent = `${libro.titulo} (${libro.genero})`;
        ul.appendChild(li);
    });
    container.appendChild(ul);
}