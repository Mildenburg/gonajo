// Importa los módulos necesarios
import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import bodyParser from 'body-parser';
import mongoose from 'mongoose';

// Crea una instancia de Express y define el puerto
const app = express();
const port = 5000;

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//              MongoDB



// URL de conexión a tu base de datos MongoDB
const url = 'mongodb://localhost:27017/biblioteca';

// Conectar a MongoDB usando Mongoose
mongoose.connect(url)
    .then(() => console.log('Conexión a MongoDB establecida correctamente'))
    .catch(error => console.error('Error al conectar a MongoDB:', error));

// Esquemas y Modelos de Mongoose
const escritorSchema = new mongoose.Schema({
    nombre: { type: String, required: true, unique: true }
});

const libroSchema = new mongoose.Schema({
    titulo: { type: String, required: true },
    genero: { type: String, required: true },
    escritor: { type: String, required: true } // El escritor ahora es una cadena de texto
});

const EscritorModel = mongoose.model('Escritor', escritorSchema);
const Libro = mongoose.model('Libro', libroSchema);

// Middleware para servir archivos estáticos desde la carpeta 'public'
app.use(express.static(path.join(__dirname, 'public')));

// Configurar Body-Parser para manejar solicitudes POST
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));



// Ruta principal
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'html', 'home.html'));
});


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//          Añadir datos 



// Ruta para añadir un nuevo escritor
app.post('/api/escritores', async (req, res) => {
    const { nombre } = req.body;
    try {
        const nuevoEscritor = new EscritorModel({ nombre });
        await nuevoEscritor.save();
        res.status(201).json(nuevoEscritor);
    } catch (error) {
        res.status(400).send('Error al añadir el escritor');
    }
});

// Ruta para añadir un nuevo libro
app.post('/api/libros', async (req, res) => {
    const { titulo, genero, escritor } = req.body;
    try {
        const nuevoLibro = new Libro({ titulo, genero, escritor });
        await nuevoLibro.save();
        res.status(201).json(nuevoLibro);
    } catch (error) {
        res.status(400).send('Error al añadir el libro');
    }
});


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//          Obtener datos 


// Ruta para obtener todos los libros y generos 
app.get('/api/libros', async (req, res) => {
    const { escritor, titulo, genero } = req.query;

    try {
        let libros;

        if (titulo) {
            libros = await Libro.find({ titulo: titulo });
        } else if (escritor) {
            libros = await Libro.find({ escritor: escritor });
        } else if (genero) {
            libros = await Libro.find({ genero: genero });
        } else {
            libros = await Libro.find();
        }

        res.status(200).json(libros);
    } catch (error) {
        res.status(500).send('Error al obtener los libros');
    }
});

// Ruta para obtener todos los escritores
app.get('/api/escritores', async (req, res) => {
    try {
        const escritores = await EscritorModel.find();
        res.status(200).json(escritores);
    } catch (error) {
        res.status(500).send('Error al obtener los escritores');
    }
});



// Iniciar el servidor
app.listen(port, () => {
    console.log(`Servidor ejecutándose en http://localhost:${port}`);
});
