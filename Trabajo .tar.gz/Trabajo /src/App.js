import React, { useState } from 'react';
import './App.css';
import 'boxicons/css/boxicons.min.css';

function App() {
  const [showLogin, setShowLogin] = useState(true);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const toggleForm = () => {
    setShowLogin(!showLogin);
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    
    // Realizar la redirección directamente al hacer clic en el botón de inicio de sesión
    window.location.href = 'http://localhost:5000/html/home2.html';
  };
  
  return (
    <div className="container">
      {showLogin ? (
        <div className="wrapper">
          <form onSubmit={handleLogin}>
            <h1>Login</h1>
            <div className="input-box">
              <input 
                type="text" 
                placeholder="Username" 
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required 
              />
              <i className='bx bxs-user'></i>
            </div>
            <div className="input-box">
              <input 
                type="password" 
                placeholder="Password" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required 
              />
              <i className='bx bxs-lock-alt'></i>
            </div>
            <div className="remember-forgot">
              <label><input type="checkbox" /> Remember me</label>
              <a href="sads">Forgot password?</a>
            </div>
            <button type="submit" className="btn">
            <a href="http://localhost:5000/html/home2.html" style={{ textDecoration: 'none', color: 'inherit' }}>Login</a>
            </button>
            <div className="register-link">
              <p>Don't have an account? <button type="button" onClick={toggleForm}>Register</button></p>
            </div>
          </form>
        </div>
      ) : (
        <div className="wrapper">
          <form>
            <h1>Register</h1>
            <div className="input-box">
              <input type="text" placeholder="Username" required />
              <i className='bx bxs-user'></i>
            </div>
            <div className="input-box">
              <input type="password" placeholder="Password" required />
              <i className='bx bxs-lock-alt'></i>
            </div>
            <div className="input-box">
              <input type="number" placeholder="Credits bibypht's" min="0" required />
              <i className='bx bx-dollar-circle'></i>
            </div>
            <button type="submit" className="btn">Register</button>
            <div className="register-link">
              <p>Already have an account? <button type="button" onClick={toggleForm}></button></p>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}

export default App;
