// Impprtacion de las clases 
import { Escritor, Aventuras, CienciaFiccion, Fantasia, Policiaca, Terror, Romantica, Poesia, Mitologia, Teatro, Cuento } from './class.js';

// Botones para añadir libros y escritores
document.getElementById('buttonlibro').addEventListener('click', addLibro);
document.getElementById('buttonEscritor').addEventListener('click', addEscritor);

// Arrays para guardar libros y escritores
const libros = [];
const escritores = [];

// Consle.log para ver la array
console.log("Libros:", libros);
console.log("Escritores:", escritores);

async function addLibro() {
    const titulo = document.getElementById('libroTitulo').value;
    const genero = document.getElementById('libroGenero').value;
    const escritorNombre = document.getElementById('libroEscritor').value;

    // Buscar el objeto Escritor correspondiente al nombre proporcionado
    const escritor = escritores.find(escritor => escritor instanceof Escritor && escritor.getNombre().trim() === escritorNombre.trim());
    if (!escritor) {
        alert('El escritor no está registrado.');
        return;
    }

    try {
        // Verificar si el libro ya está registrado
        const response = await fetch(`/api/libros?titulo=${encodeURIComponent(titulo)}&genero=${encodeURIComponent(genero)}&escritor=${encodeURIComponent(escritorNombre)}`);
        if (!response.ok) {
            const errorMessage = await response.text();
            throw new Error(errorMessage);
        }
        const librosEncontrados = await response.json();
        if (librosEncontrados.length > 0) {
            alert('El libro ya está registrado.');
            return;
        }
    } catch (error) {
        console.error('Error:', error);
        return;
    }

    let libro;
    // Dependiendo del género del libro seleccionado, crear una instancia de la clase correspondiente
    switch (genero) {
        case 'Aventuras':
            libro = new Aventuras(titulo, escritor);
            break;
        case 'Ciencia Ficción':
            libro = new CienciaFiccion(titulo, escritor);
            break;
        case 'Fantasía':
            libro = new Fantasia(titulo, escritor);
            break;
        case 'Policíaca':
            libro = new Policiaca(titulo, escritor);
            break;
        case 'Terror':
            libro = new Terror(titulo, escritor);
            break;
        case 'Romántica':
            libro = new Romantica(titulo, escritor);
            break;
        case 'Poesía':
            libro = new Poesia(titulo, escritor);
            break;
        case 'Mitología':
            libro = new Mitologia(titulo, escritor);
            break;
        case 'Teatro':
            libro = new Teatro(titulo, escritor);
            break;
        case 'Cuento':
            libro = new Cuento(titulo, escritor);
            break;
        default:
            alert('Género de libro no válido!');
            return;
    }

    libros.push(libro);
    escritor.agregarLibro(libro);

    document.getElementById('libroTitulo').value = '';
    document.getElementById('libroEscritor').value = '';
    document.getElementById('libroGenero').value = '';

    try {
        const response = await fetch('/api/libros', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ 
                titulo: libro.getTitulo(), 
                genero: libro.getGenero(), 
                escritor: escritor.getNombre() // Enviar el nombre del escritor como cadena de texto
            })
        });
        if (!response.ok) {
            const errorMessage = await response.text();
            throw new Error(errorMessage);
        }
        const data = await response.json();
        console.log('Libro añadido:', data);
    } catch (error) {
        console.error('Error:', error);
    }
    alert('Libro añadido exitosamente!');
}


// Función para añadir un escritor
async function addEscritor() {
    const nombre = document.getElementById('EscritorNombre').value;


    // Verificar si el escritor ya está registrado
    const escritorEncontrado = escritores.find(escritor => escritor instanceof Escritor && escritor.getNombre() === nombre);
    if (escritorEncontrado) {
        alert('El escritor ya está registrado.');
        return;
    }

    // Si no está registrado, procede a crear un nuevo escritor
    const escritor = new Escritor(nombre);
    escritores.push(escritor);

    document.getElementById('EscritorNombre').value = '';

    try {
        // Enviar el nuevo escritor a la API
        await fetch('/api/escritores', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ nombre: escritor.getNombre() })
        });
    } catch (error) {
        alert('Error al agregar el escritor a la base de datos:', error);
        console.error('Error al agregar el escritor a la base de datos:', error);
    }
    alert('Escritor añadido exitosamente!');

}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


// ----------------------------------------------------------------*/
document.addEventListener('DOMContentLoaded', async () => {
    try {
        const resLibros = await fetch('/api/libros');
        const dataLibros = await resLibros.json();
        libros.push(...dataLibros);

        const resEscritores = await fetch('/api/escritores');
        const dataEscritores = await resEscritores.json();
        dataEscritores.forEach(escritorData => {
            const escritor = new Escritor(escritorData.nombre);
            escritores.push(escritor);
        });
    } catch (error) {
        console.error('Error cargando datos:', error);
    }
});

