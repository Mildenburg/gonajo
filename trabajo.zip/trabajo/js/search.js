const fs = require('fs');

// Botones para buscar libros por autor 
document.getElementById('searchButtonEscritores').addEventListener('click', buscarEscritor);
document.getElementById('searchResults').value = ''; 
// Botones para buscar libros por nombre 
document.getElementById('searchButtonNomLibro').addEventListener('click', buscarLibroPorNombre);
document.getElementById('searchResultsNombre').value = ''; 
// Botones para buscar libros por genero
document.getElementById('searchButtonGenero').addEventListener('click', buscarLibroPorGenero);
document.getElementById('searchResultsGenero').value = ''; 

// Función para buscar libros por Escritor
function buscarEscritor() {
    const nombreEscritor = document.getElementById('buscarEscritor').value;
    const resultados = document.getElementById('searchResults');

    // Buscar el escritor por el nombre
    const escritor = escritores.find(e => e.getNombre() === nombreEscritor);

    // Si el escritor se ha encontrado
    if (escritor) {
        // Obtener la lista de libros escritos por ese escritor
        const librosEscritos = libros.filter(libro => libro.getEscritor().getNombre() === nombreEscritor);

        // Mostrar los resultados
        let html = `<h3>Libros escritos por ${nombreEscritor}:</h3>`;
        if (librosEscritos.length > 0) {
            html += '<ul>';
            librosEscritos.forEach(libro => {
                html += `<li>${libro.getTitulo()} (${libro.getGenero()})</li>`;
            });
            html += '</ul>';
        } else {
            html += '<p>No se han encontrado libros escritos por este escritor.</p>';
        }
        resultados.innerHTML = html;
    } else {
        // Si no se ha encontrado el escritor, mostrar un mensaje de error
        resultados.innerHTML = '<p>No se ha encontrado ningún escritor con este nombre.</p>';
    }
}



// Función para buscar libros por Nombre
function buscarLibroPorNombre() {
    const nombreLibro = document.getElementById('buscarNomLibro').value;
    const resultadosNombre = document.getElementById('searchResultsNombre');
    
    // Filtrar los libros por nombre
    const librosEncontrados = libros.filter(libro => libro.getTitulo().toLowerCase().includes(nombreLibro.toLowerCase()));

    // Mostrar los resultados
    mostrarResultados(resultadosNombre, librosEncontrados);
}


// Función para buscar libros por Género
function buscarLibroPorGenero() {
    const generoSeleccionado = document.getElementById('buscarLibroGenero').value;
    const resultadosGenero = document.getElementById('searchResultsGenero');
    
    // Filtrar los libros por género
    const librosEncontrados = libros.filter(libro => libro.getGenero().toLowerCase() === generoSeleccionado.toLowerCase());

    // Mostrar los resultados
    mostrarResultados(resultadosGenero, librosEncontrados);
}

// Función para mostrar los resultados
function mostrarResultados(elementoResultado, librosEncontrados) {
    let html = '';

    if (librosEncontrados.length > 0) {
        html += '<h3>Resultados:</h3>';
        html += '<ul>';
        librosEncontrados.forEach(libro => {
            html += `<li>${libro.getTitulo()} (${libro.getGenero()}) - ${libro.getEscritor().getNombre()}</li>`;
        });
        html += '</ul>';
    } else {
        html += '<p>No se encontraron libros.</p>';
    }

    elementoResultado.innerHTML = html;
}