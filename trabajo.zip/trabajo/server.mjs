import { fileURLToPath } from 'url';
import path from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Ahora puedes usar __dirname como lo harías en un módulo CommonJS


import express from 'express';
import fs from 'fs';
import path from 'path';
import { Escritor, Aventuras, CienciaFiccion, Fantasia, Policiaca, Terror, Romantica, Poesia, Mitologia, Teatro, Cuento } from './js/class.js';

const app = express();
const PORT = 3000;

// Middleware para parsear el cuerpo de las solicitudes como JSON
app.use(express.json());

// Ruta para obtener libros y escritores al inicio
app.get('/api/data', (req, res) => {
    fs.readFile(path.join(__dirname, 'json', 'basedatos.json'), 'utf8', (err, data) => {
        if (err) {
            console.error('Error al leer el archivo JSON:', err);
            res.status(500).json({ error: 'Error al leer el archivo JSON' });
            return;
        }
        res.json(JSON.parse(data));
    });
});

// Ruta para agregar un nuevo libro
app.post('/api/libros', (req, res) => {
    const nuevoLibro = req.body;

    fs.readFile(path.join(__dirname, 'json', 'basedatos.json'), 'utf8', (err, data) => {
        if (err) {
            console.error('Error al leer el archivo JSON:', err);
            res.status(500).json({ error: 'Error al leer el archivo JSON' });
            return;
        }

        const jsonData = JSON.parse(data);
        jsonData.libros.push(nuevoLibro);

        fs.writeFile(path.join(__dirname, 'json', 'basedatos.json'), JSON.stringify(jsonData, null, 2), 'utf8', (err) => {
            if (err) {
                console.error('Error al escribir en el archivo JSON:', err);
                res.status(500).json({ error: 'Error al escribir en el archivo JSON' });
                return;
            }

            res.status(201).json({ message: 'Libro agregado exitosamente' });
        });
    });
});

// Iniciar el servidor
app.listen(PORT, () => {
    console.log(`Servidor escuchando en el puerto ${PORT}`);
});
