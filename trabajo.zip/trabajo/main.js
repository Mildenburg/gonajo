import { Escritor, Aventuras, CienciaFiccion, Fantasia, Policiaca, Terror, Romantica, Poesia, Mitologia, Teatro, Cuento } from './class.js';

// Botones para añadir libros y escritores
document.getElementById('buttonlibro').addEventListener('click', addLibro);
document.getElementById('buttonEscritor').addEventListener('click', addEscritor);

// Arrays para guardar libros y escritores
let libros = [];
let escritores = [];

// Función para añadir un libro
function addLibro() {
    const titulo = document.getElementById('libroTitulo').value;
    const genero = document.getElementById('libroGenero').value;
    const escritorNombre = document.getElementById('libroEscritor').value;

    // Buscar el objeto Escritor correspondiente al nombre proporcionado
    const escritor = escritores.find(escritor => escritor.getNombre() === escritorNombre);

    if (!escritor) {
        alert('El escritor no está registrado.');
        return;
    }

    let libro;
    // Dependiendo del género del libro seleccionado, crear una instancia de la clase correspondiente
    switch (genero) {
        case 'Aventuras':
            libro = new Aventuras(titulo, escritor);
            break;
        case 'Ciencia Ficción':
            libro = new CienciaFiccion(titulo, escritor);
            break;
        case 'Fantasía':
            libro = new Fantasia(titulo, escritor);
            break;
        case 'Policíaca':
            libro = new Policiaca(titulo, escritor);
            break;
        case 'Terror':
            libro = new Terror(titulo, escritor);
            break;
        case 'Romántica':
            libro = new Romantica(titulo, escritor);
            break;
        case 'Poesía':
            libro = new Poesia(titulo, escritor);
            break;
        case 'Mitología':
            libro = new Mitologia(titulo, escritor);
            break;
        case 'Teatro':
            libro = new Teatro(titulo, escritor);
            break;
        case 'Cuento':
            libro = new Cuento(titulo, escritor);
            break;
        default:
            // Si el género del libro no es válido, mostrar un mensaje de error y salir de la función
            alert('Género de libro no válido!');
            return;
    }

    // Añadir el libro al array de libros
    libros.push(libro);

    // Limpiar los valores del formulario
    document.getElementById('libroTitulo').value = '';
    document.getElementById('libroEscritor').value = '';
    
    // Mostrar mensaje de confirmación
    alert('Libro añadido exitosamente!');

    // Llamar a la función para guardar los datos en formato JSON
    guardarDatos();
}

// Función para añadir un escritor
function addEscritor() {
    const nombre = document.getElementById('EscritorNombre').value;

    if (escritores.find(escritor => escritor.getNombre() === nombre)) {
        alert('El escritor ya está registrado.');
        return;
    }

    const escritor = new Escritor(nombre);

    // Añadir el escritor al array
    escritores.push(escritor);

    // Limpiar los valores del formulario
    document.getElementById('EscritorNombre').value = '';

    // Mostrar mensaje de confirmación
    alert('Escritor añadido exitosamente!');
}



/*//////////////////////////////////////////////////////////////////////////////////   

                            INTENTO JSON

//////////////////////////////////////////////////////////////////////////////////*/
// Función para guardar los datos en un archivo JSON existente
function guardarDatos() {
    const datos = {
        escritores: escritores.map(escritor => ({
            nombre: escritor.getNombre(),
            libros: escritor.getLibrosEscritos().map(libro => ({
                titulo: libro.getTitulo(),
                genero: libro.getGenero()
            }))
        }))
    };

    const datosJSON = JSON.stringify(datos);

    // Realizar el push al archivo JSON existente
    fetch('./json/basedatos.json', {
        method: 'PUT', // Utiliza el método PUT para actualizar el archivo
        headers: {
            'Content-Type': 'application/json'
        },
        body: datosJSON
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Error al realizar el push al archivo JSON.');
        }
        alert('Datos guardados exitosamente en el archivo JSON.');
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Ocurrió un error al guardar los datos en el archivo JSON.');
    });
}



/*//////////////////////////////////////////////////////////////////////////////////   

                            BUSCAR

//////////////////////////////////////////////////////////////////////////////////*/


// Botones para buscar libros por autor 
document.getElementById('searchButtonEscritores').addEventListener('click', buscarEscritor);
document.getElementById('searchResults').value = ''; 
// Botones para buscar libros por nombre 
document.getElementById('searchButtonNomLibro').addEventListener('click', buscarLibroPorNombre);
document.getElementById('searchResultsNombre').value = ''; 
// Botones para buscar libros por genero
document.getElementById('searchButtonGenero').addEventListener('click', buscarLibroPorGenero);
document.getElementById('searchResultsGenero').value = ''; 

// Función para buscar libros por Escritor
function buscarEscritor() {
    const nombreEscritor = document.getElementById('buscarEscritor').value;
    const resultados = document.getElementById('searchResults');

    // Buscar el escritor por el nombre
    const escritor = escritores.find(e => e.getNombre() === nombreEscritor);

    // Si el escritor se ha encontrado
    if (escritor) {
        // Obtener la lista de libros escritos por ese escritor
        const librosEscritos = libros.filter(libro => libro.getEscritor().getNombre() === nombreEscritor);

        // Mostrar los resultados
        let html = `<h3>Libros escritos por ${nombreEscritor}:</h3>`;
        if (librosEscritos.length > 0) {
            html += '<ul>';
            librosEscritos.forEach(libro => {
                html += `<li>${libro.getTitulo()} (${libro.getGenero()})</li>`;
            });
            html += '</ul>';
        } else {
            html += '<p>No se han encontrado libros escritos por este escritor.</p>';
        }
        resultados.innerHTML = html;
    } else {
        // Si no se ha encontrado el escritor, mostrar un mensaje de error
        resultados.innerHTML = '<p>No se ha encontrado ningún escritor con este nombre.</p>';
    }
}



// Función para buscar libros por Nombre
function buscarLibroPorNombre() {
    const nombreLibro = document.getElementById('buscarNomLibro').value;
    const resultadosNombre = document.getElementById('searchResultsNombre');
    
    // Filtrar los libros por nombre
    const librosEncontrados = libros.filter(libro => libro.getTitulo().toLowerCase().includes(nombreLibro.toLowerCase()));

    // Mostrar los resultados
    mostrarResultados(resultadosNombre, librosEncontrados);
}


// Función para buscar libros por Género
function buscarLibroPorGenero() {
    const generoSeleccionado = document.getElementById('buscarLibroGenero').value;
    const resultadosGenero = document.getElementById('searchResultsGenero');
    
    // Filtrar los libros por género
    const librosEncontrados = libros.filter(libro => libro.getGenero().toLowerCase() === generoSeleccionado.toLowerCase());

    // Mostrar los resultados
    mostrarResultados(resultadosGenero, librosEncontrados);
}

// Función para mostrar los resultados
function mostrarResultados(elementoResultado, librosEncontrados) {
    let html = '';

    if (librosEncontrados.length > 0) {
        html += '<h3>Resultados:</h3>';
        html += '<ul>';
        librosEncontrados.forEach(libro => {
            html += `<li>${libro.getTitulo()} (${libro.getGenero()}) - ${libro.getEscritor().getNombre()}</li>`;
        });
        html += '</ul>';
    } else {
        html += '<p>No se encontraron libros.</p>';
    }

    elementoResultado.innerHTML = html;
}