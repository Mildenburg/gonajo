document.addEventListener('DOMContentLoaded', () => {
    fetch('/datos')
        .then(response => response.json())
        .then(data => {
            // Aquí puedes usar los datos cargados para inicializar tu aplicación
            console.log(data);
            escritores = data.escritores;
            libros = data.libros;
        })
        .catch(error => console.error('Error al cargar los datos:', error));
});

